const { isMutant } = require('./providers/adn');

const adn1 = [
    "ATGCGA",
    "CAGTGC",
    "TTATGT",
    "AGAAGG",
    "CCCCTA",
    "TCACTG"
  ];

const adn2 = [
    "ATGAGA",
    "CTGAGC",
    "TTAAGT",
    "AGAATG",
    "CCTCGA",
    "TCACTG"
];
console.log(isMutant(adn1));
console.log(isMutant(adn2));
